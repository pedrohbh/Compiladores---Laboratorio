
#ifndef TOKEN_H
#define TOKEN_H

typedef enum {
    NUMBER,
    PLUS,
    MINUS,
    TIMES,
    LPAREN,
    RPAREN,
    ENTER
} TokenType;


#endif // TOKEN_H
