#include <stdlib.h>
#include <stdio.h>
#include "code.h"

void emit_code(AST *ast) {
    // IMPLEMENT THIS!!
    printf("Root: %p\n", ast);
}
