
#include <stdio.h>
#include "interpreter.h"

void run_ast(AST *ast) {
    // IMPLEMENT THIS!!
    printf("Root: %p\n", ast);
}
